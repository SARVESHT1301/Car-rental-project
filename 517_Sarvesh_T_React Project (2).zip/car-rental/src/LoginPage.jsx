import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './LoginPage.css';

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      // Fetch users data from db.json
      const response = await fetch('http://localhost:3001/users');
      const users = await response.json();

      // Check if the entered credentials match any user
      const user = users.find((user) => user.email === email && user.password === password);

      if (user) {
        // If credentials are correct
        setErrorMessage('Password is correct');
        navigate('/');  // Navigate to homepage or another route after successful login
      } else {
        // If credentials are incorrect
        setErrorMessage('The password you have entered is wrong');
      }
    } catch (error) {
      console.error('Error fetching users:', error);
      setErrorMessage('An error occurred. Please try again later.');
    }
  };

  return (
    <div className="login-container">
      <div className="form-box">
        <h2>Login</h2>
        <form onSubmit={handleSubmit}>
          <div className="input-group">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email"
              required
            />
          </div>
          <div className="input-group">
            <label htmlFor="password">Password</label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter your password"
              required
            />
          </div>
          <button type="submit" className="submit-btn">Login</button>
        </form>

        {errorMessage && <p className="error-message">{errorMessage}</p>}

        <p className="toggle-text">
          Don't have an account?
          <span onClick={() => navigate('/signup')} className="toggle-link"> Signup</span>
        </p>
      </div>
    </div>
  );
};

export default LoginPage;
