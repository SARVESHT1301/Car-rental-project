import React, { useState } from 'react';
import './carFinance.css';

const CarFinance = () => {
  const [price, setPrice] = useState('');
  const [downPayment, setDownPayment] = useState('');
  const [loanTerm, setLoanTerm] = useState('');
  const [interestRate, setInterestRate] = useState('');
  const [monthlyPayment, setMonthlyPayment] = useState(null);

  const calculatePayment = (e) => {
    e.preventDefault();

    const loanAmount = price - downPayment;
    const interestPerMonth = interestRate / 100 / 12;
    const numOfPayments = loanTerm * 12;

    const payment = 
      (loanAmount * interestPerMonth) / 
      (1 - Math.pow(1 + interestPerMonth, -numOfPayments));

    setMonthlyPayment(payment.toFixed(2));
  };

  return (
    <div className="car-finance">
      <h2>Car Finance Calculator</h2>
      <form onSubmit={calculatePayment}>
        <div className="form-group">
          <label htmlFor="price">Car Price ($)</label>
          <input
            type="number"
            id="price"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="downPayment">Down Payment ($)</label>
          <input
            type="number"
            id="downPayment"
            value={downPayment}
            onChange={(e) => setDownPayment(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="loanTerm">Loan Term (Years)</label>
          <input
            type="number"
            id="loanTerm"
            value={loanTerm}
            onChange={(e) => setLoanTerm(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="interestRate">Interest Rate (%)</label>
          <input
            type="number"
            id="interestRate"
            value={interestRate}
            onChange={(e) => setInterestRate(e.target.value)}
            required
          />
        </div>

        <button type="submit" className="calculate-button">Calculate Payment</button>
      </form>

      {monthlyPayment && (
        <div className="result">
          <h3>Estimated Monthly Payment: ${monthlyPayment}</h3>
        </div>
      )}
    </div>
  );
};

export default CarFinance;
