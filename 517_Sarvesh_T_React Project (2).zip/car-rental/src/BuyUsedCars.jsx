  import React from 'react';
  import './buyUsedCars.css';

  const cars = [
    {
      id: 1,
      name: 'Honda Civic',
      price: '$20,000',
      image: 'https://www.hdcarwallpapers.com/walls/2020_honda_civic_type_r_5k_4-HD.jpg',
    },
    {
      id: 2,
      name: 'Toyota Corolla',
      price: '$18,500',
      image: 'https://www.motorbiscuit.com/wp-content/uploads/2022/02/2003-to-2006-Toyota-Corolla.jpg',
    },
    {
      id: 3,
      name: 'Ford Focus',
      price: '$15,000',
      image: 'https://atl.images.passionperformance.ca/content/photos/55/27/552733-acheter-une-ford-focus-rs-d-occasion-une-bonne-idee.jpeg',
    },
    {
      id: 4,
      name: 'Hyundai Elantra',
      price: '$17,000',
      image: 'https://s3.caradvice.com.au/wp-content/uploads/2016/02/Elantra-Elite-030.jpg',
    },
  ];

  const BuyUsedCars = () => {
    return (
      <div className="buy-used-cars">
        <h2>Available Used Cars</h2>
        <div className="car-list">
          {cars.map((car) => (
            <div key={car.id} className="car-item">
              <img src={car.image} alt={car.name} />
              <h3>{car.name}</h3>
              <p>{car.price}</p>
              <button className="buy-button">Buy Now</button>
            </div>
          ))}
        </div>
      </div>
    );
  };

  export default BuyUsedCars;
