import React, { useState } from 'react';
import './sellCar.css';

const carBrands = [
  'Toyota', 'Honda', 'Ford', 'Chevrolet', 'Nissan', 'BMW', 'Mercedes-Benz',
  'Volkswagen', 'Audi', 'Hyundai', 'Kia', 'Subaru', 'Mazda', 'Volvo', 
  'Porsche', 'Jaguar', 'Land Rover', 'Ferrari', 'Lamborghini', 'Mitsubishi', 
  'Jeep', 'Tesla', 'Peugeot', 'Renault', 'Fiat', 'Suzuki', 'Dodge', 'Lexus', 
  'Acura', 'Infiniti', 'Citroën', 'Mini', 'Bentley', 'Rolls-Royce'
];

const SellCar = () => {
  const [formData, setFormData] = useState({
    brand: '',
    model: '',
    year: '',
    price: '',
    contact: '',
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert('Your car has been listed for sale!');
    setFormData({
      brand: '',
      model: '',
      year: '',
      price: '',
      contact: '',
    });
  };

  return (
    <div className="sell-car">
      <h2>Sell Your Car</h2>
      <form onSubmit={handleSubmit}>
        
        <div className="form-group">
          <label htmlFor="brand">Car Brand</label>
          <select
            id="brand"
            name="brand"
            value={formData.brand}
            onChange={handleChange}
            required
          >
            <option value="">-- Select Car Brand --</option>
            {carBrands.map((brand) => (
              <option key={brand} value={brand}>
                {brand}
              </option>
            ))}
          </select>
        </div>

        <div className="form-group">
          <label htmlFor="model">Car Model</label>
          <input
            type="text"
            id="model"
            name="model"
            value={formData.model}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="year">Manufacturing Year</label>
          <input
            type="number"
            id="year"
            name="year"
            value={formData.year}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="price">Asking Price ($)</label>
          <input
            type="number"
            id="price"
            name="price"
            value={formData.price}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="contact">Contact Information</label>
          <input
            type="text"
            id="contact"
            name="contact"
            value={formData.contact}
            onChange={handleChange}
            required
          />
        </div>

        <button type="submit" className="submit-button">List My Car</button>
      </form>
    </div>
  );
};

export default SellCar;
