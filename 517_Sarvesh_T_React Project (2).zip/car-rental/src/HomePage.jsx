import React from 'react';
import { useNavigate } from 'react-router-dom';
import './homepage.css';

const HomePage = () => {
  const navigate = useNavigate();

  const handleBuyUsedCars = () => navigate('/buy-used-cars');
  const handleSellCar = () => navigate('/sell-car');
  const handleCarFinance = () => navigate('/car-finance');
  const handleNewCars = () => navigate('/new-cars');
  const handleCarService = () => navigate('/car-service');

  return (
    <div>
      {/* Navbar */}
      <nav className="navbar">
        <div className="logo">
          <img src="https://i.pinimg.com/564x/28/3b/9f/283b9ff825f903d34a76eb4158a0af85.jpg" alt="GAS MONKEY GARAGE" />
        </div>
        <ul>
          <li><button onClick={handleBuyUsedCars}>Buy Used Cars</button></li>
          <li><button onClick={handleSellCar}>Sell Car</button></li>
          <li><button onClick={handleCarFinance}>Car Finance</button></li>
          <li><button onClick={handleNewCars}>New Cars</button></li>
          <li><button onClick={handleCarService}>Car Service</button></li>
        </ul>
        <div className="account">
          <span><a href="/login">Sign in / Login</a></span>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="hero-section">
        <h1>Welcome to GAS MONKEY GARAGE</h1>
        <p>Your all-in-one car universe</p>
        <div className="search-bar">
          <input type="text" placeholder="Search your car" />
          <button>View</button>
        </div>
      </section>

      {/* Brands Section */}
      <section className="brands-section">
        <h2>Top Brands</h2>
        <div className="brands-list">
          <img src="https://i.pinimg.com/564x/80/0d/e2/800de2b4b41959f70be86e6c7454272c.jpg" alt="Maruti" />
          <img src="https://i.pinimg.com/564x/18/af/72/18af72dd5c1c8720e33ad26104a9bbf4.jpg" alt="Hyundai" />
          <img src="https://i.pinimg.com/564x/fa/49/dc/fa49dcaf6ae263e7e796590c6c610cd4.jpg" alt="Honda" />
          <img src="https://i.pinimg.com/564x/1e/ec/0e/1eec0ecbfb89b4d802792243dfc4067d.jpg" alt="Tata" />
          <img src="https://i.pinimg.com/564x/7a/87/fd/7a87fdfdd242ebdb56eae95efb21e32c.jpg" alt="Renault" />
          <img src="https://i.pinimg.com/control/564x/30/74/1b/30741ba5dd1db6c9e550d526e643363e.jpg" alt="Kia" />
          <img src="https://i.pinimg.com/736x/dd/4e/94/dd4e947f5f1f0b46cb97b0e6ac23892b.jpg" alt="Mahindra" />
          <img src="https://i.pinimg.com/564x/b3/68/8e/b3688e2adedbb47ff6a6abbcf93c5d8e.jpg" alt="Ford" />
        </div>
      </section>

      {/* Footer */}
      <footer className="footer">
        <p>&copy; 2024 GAS MONKEY GARAGE. All Rights Reserved.</p>
      </footer>
    </div>
  );
};

export default HomePage;
