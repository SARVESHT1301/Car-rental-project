import React from 'react';
import './newCars.css'; // Import CSS for new cars

const newCars = [
  {
    id: 1,
    name: 'Tesla Model S',
    price: '$90,000',
    image: 'https://s1.cdn.autoevolution.com/images/gallery/TESLA-MOTORS-Model-S-4693_61.jpg',
  },
  {
    id: 2,
    name: 'BMW i8',
    price: '$140,000',
    image: 'https://i.gaw.to/content/photos/21/58/215890_2015_BMW_i8.jpg',
  },
  {
    id: 3,
    name: 'Audi e-tron GT',
    price: '$99,800',
    image: 'https://assets.newatlas.com/dims4/default/8c93ac5/2147483647/strip/true/crop/3508x2340+0+0/resize/1439x960!/quality/90/?url=http:%2F%2Fnewatlas-brightspot.s3.amazonaws.com%2F9d%2F09%2Fad76dd6c44fbbf5b679632613888%2Fa210816-medium.jpg',
  },
  {
    id: 4,
    name: 'Mercedes-Benz EQS',
    price: '$110,000',
    image: 'https://thedetroitbureau.com/wp-content/uploads/2021/04/Mercedes-EQS-nose.jpg',
  },
];

const NewCars = () => {
  return (
    <div className="new-cars">
      <h2>Explore New Cars</h2>
      <div className="car-list">
        {newCars.map((car) => (
          <div key={car.id} className="car-item">
            <img src={car.image} alt={car.name} />
            <h3>{car.name}</h3>
            <p>{car.price}</p>
            <button className="buy-button">Buy Now</button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default NewCars;
