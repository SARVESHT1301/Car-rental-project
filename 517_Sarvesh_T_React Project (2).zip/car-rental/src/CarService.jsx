import React, { useState } from 'react';
import './carService.css'; // Import CSS for car service

const CarService = () => {
  const [serviceType, setServiceType] = useState('');
  const [carModel, setCarModel] = useState('');
  const [contactInfo, setContactInfo] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    // Process booking logic here
    setSubmitted(true);
  };

  const handleNewBooking = () => {
    // Reset the form for a new booking
    setServiceType('');
    setCarModel('');
    setContactInfo('');
    setSubmitted(false);
  };

  return (
    <div className="car-service">
      <h2>Book Your Car Service</h2>
      {submitted ? (
        <div className="receipt">
          <h3>Service Booking Receipt</h3>
          <p>Thank you for booking your car service!</p>
          <p><strong>Service Type:</strong> {serviceType}</p>
          <p><strong>Car Model:</strong> {carModel}</p>
          <p><strong>Contact Info:</strong> {contactInfo}</p>
          <p>We will contact you shortly to confirm your service.</p>
          <button onClick={handleNewBooking} className="new-booking-button">
            Book Another Service
          </button>
        </div>
      ) : (
        <div>
          <p>Select from the available car services below:</p>
          <div className="service-cards">
            <div
              className={`service-card ${serviceType === 'general' ? 'selected' : ''}`}
              onClick={() => setServiceType('general')}
            >
              <img src="https://i.pinimg.com/564x/9c/21/7d/9c217d0cb2c281571154e818f6d75bd2.jpg" alt="General Service" />
              
              <p>General Service</p>
            </div>

            <div
              className={`service-card ${serviceType === 'oil-change' ? 'selected' : ''}`}
              onClick={() => setServiceType('oil-change')}
            >
              <img src="https://i.pinimg.com/736x/d8/cf/04/d8cf042e8ae1acc1320260e5829718aa.jpg" alt="Oil Change" />
             
              <p>Oil Change</p>
            </div>

            <div
              className={`service-card ${serviceType === 'brakes' ? 'selected' : ''}`}
              onClick={() => setServiceType('brakes')}
            >
              <img src="https://i.pinimg.com/564x/58/24/cf/5824cfd164f5045af3529fdda2ca37b2.jpg" alt="Brake Repair" />
              
              <p>Brake Repair</p>
            </div>

            <div
              className={`service-card ${serviceType === 'battery' ? 'selected' : ''}`}
              onClick={() => setServiceType('battery')}
            >
              <img src="https://i.pinimg.com/564x/3d/0f/cc/3d0fccb4f02aec256aa6b4b2bba9bd2e.jpg" alt="Battery Replacement" />
              <p>Battery Replacement</p>
            </div>

            <div
              className={`service-card ${serviceType === 'tyres' ? 'selected' : ''}`}
              onClick={() => setServiceType('tyres')}
            >
              <img src="https://i.pinimg.com/564x/fc/88/a9/fc88a95eda2004c3a798bbc2da387e69.jpg" alt="Tyre Replacement" />
              <p>Tyre Replacement</p>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="service-form">
            <div className="form-group">
              <label htmlFor="carModel">Car Model</label>
              <input
                type="text"
                id="carModel"
                value={carModel}
                onChange={(e) => setCarModel(e.target.value)}
                required
                placeholder="Enter your car model"
              />
            </div>

            <div className="form-group">
              <label htmlFor="contactInfo">Contact Information</label>
              <input
                type="text"
                id="contactInfo"
                value={contactInfo}
                onChange={(e) => setContactInfo(e.target.value)}
                required
                placeholder="Enter your phone number or email"
              />
            </div>

            <button type="submit" className="submit-button">Book Service</button>
          </form>
        </div>
      )}
    </div>
  );
};

export default CarService;
