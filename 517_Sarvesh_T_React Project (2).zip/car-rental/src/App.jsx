import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import LoginPage from './LoginPage';
import SignupPage from './SignupPage';
import HomePage from './HomePage';
import BuyUsedCars from './BuyUsedCars';
import SellCar from './SellCar';
import CarFinance from './CarFinance';
import NewCars from './NewCars';
import CarService from './CarService';


const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/Login" element={<LoginPage />} />
        <Route path="/signup" element={<SignupPage />} />
        <Route path="/" element={< HomePage/>} />
        <Route path="/buy-used-cars" element={<BuyUsedCars />} />
        <Route path="/sell-car" element={<SellCar />} />
        <Route path="/car-finance" element={<CarFinance />} />
        <Route path="/new-cars" element={<NewCars />} />
        <Route path="/car-service" element={<CarService />} />
        
        
      </Routes>
    </Router>
  );
};

export default App;
