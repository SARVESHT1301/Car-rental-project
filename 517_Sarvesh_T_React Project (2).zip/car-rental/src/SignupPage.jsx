import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './signup.css';

const SignupPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: ''
  });
  const [users, setUsers] = useState([]);
  const [nameError, setNameError] = useState('');
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [submissionError, setSubmissionError] = useState('');
  const navigate = useNavigate();

  // Fetch existing users on component mount
  useEffect(() => {
    fetch('http://localhost:3001/users')
      .then(response => response.json())
      .then(data => setUsers(data))
      .catch(error => console.error('Error fetching users:', error));
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });

    // Validate name
    if (name === 'name') {
      const nameExists = users.some(user => user.name === value);
      setNameError(nameExists ? 'This name is already used' : '');
    }

    // Validate email
    if (name === 'email') {
      const emailExists = users.some(user => user.email === value);
      setEmailError(emailExists ? 'This email is already used' : '');
    }

    // Validate password length
    if (name === 'password') {
      setPasswordError(value.length < 6 ? 'Password must be 6-8 characters' : '');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    // Check for any remaining validation errors
    if (nameError || emailError || passwordError) {
      setSubmissionError('Entered data is invalid. Please re-enter.');
      return;
    }

    // Proceed with storing data if all validations pass
    try {
      const response = await fetch('http://localhost:3001/users', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        console.log('User data stored successfully');
        navigate('/login'); 
      } else {
        console.error('Failed to store user data');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  return (
    <div className="signup-container">
      <div className="signup-box">
        <h2>Sign Up</h2>
        <form onSubmit={handleSubmit}>
          <div className="input-group">
            <label htmlFor="name">Name</label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder="Enter your name"
              required
            />
            {nameError && <p className="error-text">{nameError}</p>}
          </div>
          <div className="input-group">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="Enter your email"
              required
            />
            {emailError && <p className="error-text">{emailError}</p>}
          </div>
          <div className="input-group">
            <label htmlFor="password">Password</label>
            <input
              type="password"
              id="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              placeholder="Enter your password"
              required
            />
            {passwordError && <p className="error-text">{passwordError}</p>}
          </div>
          {submissionError && <p className="error-text">{submissionError}</p>}
          <button type="submit" className="signup-btn">Sign Up</button>
        </form>
        <p className="navigate-text">
          Already have an account? <span onClick={() => navigate('/login')} className="login-link">Login</span>
        </p>
      </div>
    </div>
  );
};

export default SignupPage;
